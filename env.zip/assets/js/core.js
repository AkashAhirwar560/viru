"use strict";
(function($) {
  $(document).ready(function() {
    const DIV_CARD = 'div.card';
    $('[data-toggle="tooltip"]').tooltip();
    $('[data-toggle="popover"]').popover({
      html: true
    });
    $('[data-toggle="card-remove"]').on('click', function(e) {
      let $card = $(this).closest(DIV_CARD);

      $card.remove();

      e.preventDefault();
      return false;
    });
    $('[data-toggle="card-collapse"]').on('click', function(e) {
      let $card = $(this).closest(DIV_CARD);
      $card.toggleClass('card-collapsed');
      e.preventDefault();
      return false;
    });

    /** Function for fullscreen card */
    $('[data-toggle="card-fullscreen"]').on('click', function(e) {
      let $card = $(this).closest(DIV_CARD);
      $card.toggleClass('card-fullscreen').removeClass('card-collapsed');
      e.preventDefault();
      return false;
    });

    if ($('.chart-circle').length) {
      require(['circle-progress'], function() {
        $('.chart-circle').each(function() {
          let $this = $(this);
          $this.circleProgress({
            fill: {
              color: tabler.colors[$this.attr('data-color')] || tabler.colors.blue
            },
            size: $this.height(),
            startAngle: -Math.PI / 4 * 2,
            emptyFill: '#F4F4F4',
            lineCap: 'round'
          });
        });
      });
    }
  });
  
})(jQuery);