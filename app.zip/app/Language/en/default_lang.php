<?php 
// Home Page
$lang["light"] = "Light";
$lang["dark"]  = "Dark";
$lang["auto"]  = "Auto";
$lang["Modern_online_tool_to_increase_popularity_on_social_networks"] = "Modern online tool to increase popularity on social networks";

$lang["Order_now"] = "Order now";
$lang["Save"] = "Save";

$lang["Share_your_feedback"]    = "Share your feedback";
$lang["Load_More"]              = "Load More";
$lang["Submit"]                 = "Submit";
$lang["Close"]                  = "Close";
$lang["Submit_Your_Review"]     = "Submit Your Review";
$lang["Your_Name"]              = "Your Name";
$lang["Email"]                  = "Email";
$lang["Phone"]                  = "Phone";
$lang["Address"]                = "Address";
$lang["Order_ID"]               = "Order ID";
$lang["Payment"]                = "Payment";
$lang["Other"]                  = "Other";
$lang["Rating"]                 = "Rating";
$lang["Your_Review"]            = "Your Review";
$lang["Subject"]                = "Subject";
$lang["Your_Order_ID"]          = "Your Order ID";
$lang["Transaction_ID"]         = "Transaction ID";
$lang["Message"]                = "Message";
$lang["Appcept_all_cookies"]    = "Appcept all cookies!";


// Order
$lang["Get_Started"] = "Get Started";
$lang["Please_review_the_Order_Summary_again_before_entering_checkout_information"] = "Please review the Order Summary again before entering checkout information";
$lang["Order_form"] = "Order form";
$lang["Enter_Link"] = "Enter Link";
$lang["Your_Email"] = "Your Email";
$lang["Enter_your_email"] = "Enter your email...";
$lang["Choose_a_Package"] = "Choose a Package";
$lang["Switch_Package"] = "Switch Package";
$lang["Please_select_a_valid_package"] = "Please select a valid package.";
$lang["Continue"] = "Continue";
$lang["Review_Your_Order"] = "Review Your Order";
$lang["Link"] = "Link";
$lang["Quantity"] = "Quantity";
$lang["Sub_Total"] = "Sub Total";
$lang["Bill_Information"] = "Bill Information";
$lang["Switch_Email"] = "Switch Email";
$lang["Subscribe_to_our_newsletter"] = "Subscribe to our newsletter";
$lang["First_name"] = "First name";
$lang["Last_name"] = "Last name";
$lang["Phone_Number"] = "Phone Number";
$lang["Invalid_number"] = "Invalid number";
$lang["Payment_Options"] = "Payment Options";
$lang["Payment_Method"] = "Payment Method";
$lang["No_payment_method_available"] = "No payment method available";
$lang["Coupon_Code"] = "Coupon Code....";
$lang["Apply"] = "Apply";
$lang["Total"] = "Total";
$lang["Complete_payment"] = "Complete payment";
$lang["Note"] = "Note";
$lang["Your_payment_information_is_secure_and_encrypted"] = "Your payment information is secure and encrypted.";
$lang["Delivery_of_your_order_will_start_automatically_after_successful_payment_An_order_confirmation_email_will_be_sent_with_order_number_and_details"] = "Delivery of your order will start automatically after successful payment. An order confirmation email will be sent with order number and details.";
$lang["Awesome_Youve_just_saved_with_this_promo_code"] = "Awesome! You've just saved with this promo code!";
$lang["Subtotal"] = "Subtotal";
$lang["Coupon_amount"] = "Coupon amount";

$lang["Thank_You_for_Your_Order"] = "Thank You for Your Order!";
$lang["We_appreciate_your_most_recent_purchase_and_hope_you_enjoyed_your_purchase_An_email_receipt_including_the_details_about_your_order_has_been_sent_to_your_email_address"] = "We appreciate your most recent purchase and hope you enjoyed your purchase. An email receipt including the details about your order has been sent to your email address";
$lang["Order_Details"] = "Order Details";
$lang["Copy_to_Clipboard"] = "Copy to Clipboard";
$lang["Copied"] = "Copied!";
$lang["Total_Charge_including_tax"] = "Total Charge (including tax)";
$lang["Track_Your_Order"] = "Track Your Order";
$lang["Back_to_home"] = "Back to home";
$lang["Payment_Failed"] = "Payment Failed";
$lang["Were_sorry_but_we_couldnt_process_your_payment_Please_check_your_payment_details_and_try_again"] = "We're sorry, but we couldn't process your payment. Please check your payment details and try again.";
$lang["What_Would_You_Like_to_Do_Next"] = "What Would You Like to Do Next?";
$lang["Contact_Us"] = "Contact Us";
$lang["Contact_Information"] = "Contact Information";

$lang["Track_Order"] = "Track Order";
$lang["Enter_your_tracking_number_to_see_the_status_of_your_order_You_can_find_the_tracking_number_in_the_email_confirmation_we_sent_to_your_inbox"] = "Enter your tracking number to see the status of your order. You can find the tracking number in the email confirmation we sent to your inbox.";
$lang["Order_Tracking_Result"] = "Order Tracking Result";
$lang["Below_are_the_details_of_your_tracked_order"] = "Below are the details of your tracked order.";
$lang["Payment_Information"] = "Payment Information";
$lang["Payment_status"] = "Payment status";
$lang["Total_Charge"] = "Total Charge";
$lang["Package_Details"] = "Package Details";
$lang["Package_Name"] = "Package Name";
$lang["Order_Status"] = "Order Status";
$lang["Placed_Order_Date"] = "Placed Order Date";
$lang["Export_PDF"] = "Export PDF";

$lang["Completed"] = "Completed";
$lang["Processing"] = "Processing";
$lang["In_progress"] = "In progress";
$lang["Pending"] = "Pending";
$lang["Partial"] = "Partial";
$lang["Canceled"] = "Canceled";
$lang["Refunded"] = "Refunded";
$lang["Awaiting"] = "Awaiting";
$lang["Unknown"] = "Unknown";
$lang["N_a"] = "N/A";


// Validate
$lang["Please_kindly_verify_the_reCAPTCHA_to_proceed"] = "Please kindly verify the reCAPTCHA to proceed";
$lang["Please_enter_your_name"] = "Please enter your name";
$lang["The_field_must_be_at_least_3_characters_long"] = "The field must be at least 3 characters long";
$lang["The_name_cannot_be_longer_than_100_characters"] = "The name cannot be longer than 100 characters";
$lang["Please_enter_your_email_address"] = "Please enter your email address";
$lang["Please_enter_a_valid_email_address"] = "Please enter a valid email address";
$lang["Please_enter_the_order_ID"] = "Please enter the order ID";
$lang["Invalid_order_ID"] = "Invalid order ID";
$lang["Please_select_a_rating"] = "Please select a rating";
$lang["The_rating_must_be_an_integer"] = "The rating must be an integer";
$lang["Invalid_Rating"] = "Invalid Rating";
$lang["Please_enter_a_review"] = "Please enter a review";
$lang["The_review_must_be_at_least_10_characters_long"] = "The review must be at least 10 characters long";
$lang["The_message_must_be_at_least_50_characters_long"] = "The message must be at least 50 characters long";
$lang["The_review_cannot_be_longer_than_1000_characters"] = "The review cannot be longer than 1000 characters";
$lang["Please_enter_the_transaction_ID"] = "Please enter the transaction ID";
$lang["Invalid_transaction_ID"] = "Invalid transaction ID";
$lang["The_field_is_required"] = "The field is required";
$lang["The_service_package_is_required"] = "The service package is required";
$lang["Invalid_service_package_Please_check_again"] = "Invalid service package. Please check again";
$lang["This_field_is_optional_but_if_filled_please_use_the_correct_format"] = "This field is optional, but if filled, please use the correct format";
$lang["Please_select_a_payment_method"] = "Please select a payment method";
$lang["Invalid_Payment_Method"] = "Invalid Payment Method";
$lang["Please_make_sure_all_fields_are_filled_out_correctly"] = "Please make sure all fields are filled out correctly";
$lang["Your_request_cannot_be_processed_at_this_time_Please_try_again_later"] = "Your request cannot be processed at this time. Please try again later.";
$lang["There_was_an_issue_saving_your_cart_Please_try_again_or_refresh_the_page"] = "There was an issue saving your cart. Please try again or refresh the page.";
$lang["There_was_an_issue_saving_your_cart_Please_try_again"] = "There was an issue saving your cart. Please try again";
$lang["There_was_an_issue_with_your_cart_Please_place_your_order_again"] = "There was an issue with your cart. Please place your order again!";
$lang["The_selected_payment_option_is_not_available"] = "The selected payment option is not available";
$lang["We_are_unable_to_process_your_payment_at_the_moment_Please_try_again_later"] = "We are unable to process your payment at the moment. Please try again later.";
$lang["Invalid_or_expired_coupon_code_Please_try_again_later"] = "Invalid or expired coupon code. Please try again later.";
$lang["There_was_an_issue_creating_your_checkout_Please_try_again"] = "There was an issue creating your checkout. Please try again";

$lang["Please_wait_a_moment_you_will_be_redirected_to_the_payment_page"] = "Please wait a moment, you will be redirected to the payment page.";

$lang["Your_order_has_been_successfully_added_to_the_cart_Please_wait_you_will_be_redirected_to_the_checkout_page_shortly"] = "Your order has been successfully added to the cart. Please wait, you will be redirected to the checkout page shortly.";

$lang["Youve_already_submitted_a_review_for_this_order_Please_allow_some_time_before_posting_another_review"] = "You've already submitted a review for this order. Please allow some time before posting another review.";
$lang["Thank_you_Your_review_has_been_successfully_updated"] = "Thank you! Your review has been successfully updated.";
$lang["Thank_you_Your_message_has_been_successfully_submitted"] = "Thank you! Your message has been successfully submitted.";
$lang["An_error_occurred_Please_try_again_later"] = "An error occurred. Please try again later";

// Blog
$lang["Category"] = "Category";
$lang["Unlock_new_strategies_and_techniques_with_our_indepth_articles_designed_to_help_you_optimize_your_marketing_and_grow_your_digital_presence"] = "Unlock new strategies and techniques with our in-depth articles, designed to help you optimize your marketing and grow your digital presence";

$lang["Next_post"] = "Next post";
$lang["Previous_post"] = "Previous post";
$lang["Share_this_article"] = "Share this article";
$lang["by"] = "by";
$lang["Follow_Us"] = "Follow Us";
$lang["Post_Categories"] = "Post Categories";
$lang["Posts_in_this_Category"] = "Posts in this Category";



// 404
$lang["Not_found"] = "Not found";
$lang["You_are_requesting_a_page_that_does_not_exists"] = "You are requesting a page that does not exists!";
$lang["This_may_have_occurred_because_of_several_reasons"] = "This may have occurred because of several reasons:";
$lang["The_page_you_requested_does_not_exist"] = "The page you requested does not exist.";
$lang["The_link_you_clicked_is_no_longer_available"] = "The link you clicked is no longer available.";
$lang["The_page_may_have_moved_to_a_new_location"] = "The page may have moved to a new location.";
$lang["An_error_may_have_occurred"] = "An error may have occurred.";
$lang["You_are_not_authorized_to_view_the_requested_resource"] = "You are not authorized to view the requested resource.";
$lang["Please_try_again_in_a_few_minutes_or_alternatively_return_to_the_homepage_by"] = "Please try again in a few minutes, or alternatively return to the homepage by";
$lang["clicking_here"] = "clicking here";