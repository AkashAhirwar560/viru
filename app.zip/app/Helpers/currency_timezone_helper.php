<?php

/**
 * Get location info by IP using GeoPlugin
 */
function get_location_info_by_ip($ip_address = null)
{
    $session = \Config\Services::session();

    $stored_ip = session_get('stored_ip');
    $location_info = session_get('location_info');
    $location_info_time = session_get('location_info_time');
    $max_session_duration = 86400; // 24 hours

    if (empty($ip_address)) {
        $ip_address = service('request')->getIPAddress();
    }

    if ($stored_ip && $stored_ip == $ip_address && (time() - $location_info_time) <= $max_session_duration) {
        return $location_info;
    }

    $api_url = "http://www.geoplugin.net/php.gp?ip={$ip_address}";

    try {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $api_url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 5);
        $response = curl_exec($ch);
        curl_close($ch);

        if ($response !== false) {
            $ip_data = @unserialize($response);

            if (!empty($ip_data['geoplugin_countryName'])) {
                $location_info = [
                    'status' => true,
                    'error_message' => '',
                    'data' => [
                        'country' => $ip_data['geoplugin_countryName'] ?? 'Unknown',
                        'country_code' => $ip_data['geoplugin_countryCode'] ?? 'Unknown',
                        'timezone' => $ip_data['geoplugin_timezone'] ?? 'UTC',
                        'city' => $ip_data['geoplugin_city'] ?? 'Unknown',
                    ],
                ];

                session_set('stored_ip', $ip_address);
                session_set('location_info', $location_info);
                session_set('location_info_time', time());

                return $location_info;
            }
        }
    } catch (\Exception $e) {
        log_message('error', 'GeoPlugin API error: ' . $e->getMessage());
    }

    return [
        'status' => false,
        'error_message' => 'Failed to fetch data',
        'data' => [
            'country' => 'Unknown',
            'country_code' => 'Unknown',
            'timezone' => 'UTC',
            'city' => 'Unknown',
        ],
    ];
}

/**
 * Get timezone by IP
 */
if (!function_exists('get_timezone_by_ip')) {
    function get_timezone_by_ip($ip_address = null)
    {
        $location_info = get_location_info_by_ip($ip_address);
        if ($location_info['status'] && isset($location_info['data']['timezone']) && $location_info['data']['timezone'] != 'Unknown') {
            return $location_info['data']['timezone'];
        }
        return date_default_timezone_get();
    }
}

/**
 * Get user's timezone
 */
if (!function_exists("get_user_timezone")) {
    function get_user_timezone()
    {
        if (is_user_logged_in()) {
            return session_get('user')['timezone'] ?? 'UTC';
        } else {
            return get_timezone_by_ip();
        }
    }
}

/**
 * Return an array of timezones
 */
function tz_list()
{
    $timezoneIdentifiers = DateTimeZone::listIdentifiers();
    $utcTime = new DateTime('now', new DateTimeZone('UTC'));

    $tempTimezones = [];
    foreach ($timezoneIdentifiers as $timezoneIdentifier) {
        $currentTimezone = new DateTimeZone($timezoneIdentifier);
        $tempTimezones[] = [
            'offset' => (int) $currentTimezone->getOffset($utcTime),
            'identifier' => $timezoneIdentifier,
        ];
    }

    usort($tempTimezones, function ($a, $b) {
        return ($a['offset'] == $b['offset'])
            ? strcmp($a['identifier'], $b['identifier'])
            : $a['offset'] - $b['offset'];
    });

    $timezoneList = [];
    foreach ($tempTimezones as $key => $tz) {
        $sign = ($tz['offset'] >= 0) ? '+' : '-';
        $offset = gmdate('H:i', abs($tz['offset']));
        $timezoneList[$key]['time'] = '(UTC ' . $sign . $offset . ') ' . $tz['identifier'];
        $timezoneList[$key]['zone'] = $tz['identifier'];
    }
    return $timezoneList;
}

/**
 * Convert timezone
 */
if (!function_exists('convert_timezone')) {
    function convert_timezone($datetime, $case = 'user')
    {
        $zonesystem = date_default_timezone_get();
        $zoneuser = get_user_timezone();

        if (!in_array($zoneuser, DateTimeZone::listIdentifiers())) {
            $zoneuser = 'UTC';
        }

        switch ($case) {
            case 'user':
                $currentTZ = new DateTimeZone($zonesystem);
                $newTZ = new DateTimeZone($zoneuser);
                break;
            case 'system':
                $currentTZ = new DateTimeZone($zoneuser);
                $newTZ = new DateTimeZone($zonesystem);
                break;
        }

        $date = new DateTime($datetime, $currentTZ);
        $date->setTimezone($newTZ);
        return $date->format('Y-m-d H:i:s');
    }
}

/**
 * Format client order date
 */
function client_placed_order_date($input_datetime)
{
    $input_datetime = convert_timezone($input_datetime, 'user');
    return date("F j, Y H:i:s", strtotime($input_datetime));
}

/**
 * Price formatting functions
 */
if (!function_exists('show_price_format')) {
    function show_price_format($input_price, $show_currency_symbol = false, $is_new_format = false, $option = [])
    {
        $input_price = (double) $input_price;
        $curency_symbol = null;
        if ($show_currency_symbol) {
            $curency_symbol = get_option('currency_symbol', "$");
        }
        return $curency_symbol . $input_price;
    }
}

if (!function_exists('format_price_with_currency')) {
    function format_price_with_currency($number, $currency = '', $decimals = '', $decimal_separator = '', $thousand_separator = '', $currency_position = '')
    {
        if (!is_numeric($number)) {
            return null;
        }

        $setting_thousand_separator = get_app_setting('currency_thousand_separator');
        $setting_decimal_separator = get_app_setting('currency_decimal_separator');

        $setting_thousand_separator = ($setting_thousand_separator === 'space') ? ' ' : (($setting_thousand_separator === 'comma') ? ',' : '.');
        $setting_decimal_separator = ($setting_decimal_separator === 'dot') ? '.' : ',';

        $decimals = !empty($decimals) ? $decimals : get_app_setting('currency_decimal');
        $currency = !empty($currency) ? $currency : get_app_setting('currency_symbol');
        $currency_position = !empty($currency_position) ? $currency_position : get_app_setting('currency_position');
        $decimal_separator = !empty($decimal_separator) ? $decimal_separator : $setting_decimal_separator;
        $thousand_separator = !empty($thousand_separator) ? $thousand_separator : $setting_thousand_separator;

        $formatted_number = number_format($number, $decimals, $decimal_separator, $thousand_separator);

        return ($currency_position == 'before') ? $currency . $formatted_number : $formatted_number . $currency;
    }
}

/**
 * Currency and payment settings
 */
if (!function_exists("currency_codes")) {
    function currency_codes()
    {
        return [
            "AUD" => "AUD - Australian dollar",
            "BRL" => "BRL - Brazilian dollar",
            "CAD" => "CAD - Canadian dollar",
            "CZK" => "CZK - Czech koruna",
            "DKK" => "DKK - Danish krone",
            "EUR" => "EUR - Euro",
            "HKD" => "HKD - Hong Kong dollar",
            "HUF" => "HUF - Hungarian forint",
            "INR" => "INR - Indian rupee",
            "ILS" => "ILS - Israeli",
            "JPY" => "JPY - Japanese yen",
            "MYR" => "MYR - Malaysian ringgit",
            "MXN" => "MXN - Mexican peso",
            "TWD" => "TWD - New Taiwan dollar",
            "NZD" => "NZD - New Zealand dollar",
            "NOK" => "NOK - Norwegian krone",
            "PHP" => "PHP - Philippine peso",
            "PLN" => "PLN - Polish złoty",
            "GBP" => "GBP - Pound sterling",
            "RUB" => "RUB - Russian ruble",
            "SGD" => "SGD - Singapore dollar",
            "SEK" => "SEK - Swedish krona",
            "CHF" => "CHF - Swiss franc",
            "THB" => "THB - Thai baht",
            "USD" => "USD - United States dollar",
        ];
    }
}

if (!function_exists("coinpayments_coin_setting")) {
    function coinpayments_coin_setting()
    {
        return [
            'BTC' => 'Bitcoin',
            'LTC' => 'Litecoin',
            'ETH' => 'Ether',
            'BCH' => 'Bitcoin Cash',
            'DASH' => 'DASH',
            'XRP' => 'Ripple',
            'LTCT' => 'Litecoin Testnet for testing',
        ];
    }
}

if (!function_exists("midtrans_payment_setting")) {
    function midtrans_payment_setting()
    {
        return [
            "credit_card" => 'credit_card',
            "gopay" => 'gopay',
            "mandiri_clickpay" => 'mandiri_clickpay',
            "cimb_clicks" => 'cimb_clicks',
            "bca_klikbca" => 'bca_klikbca',
            "bca_klikpay" => 'bca_klikpay',
            "bri_epay" => 'bri_epay',
            "telkomsel_cash" => 'telkomsel_cash',
            "echannel" => 'echannel',
            "bbm_money" => 'bbm_money',
            "xl_tunai" => 'xl_tunai',
            "indosat_dompetku" => 'indosat_dompetku',
            "mandiri_ecash" => 'mandiri_ecash',
            "permata_va" => 'permata_va',
            "bca_va" => 'bca_va',
            "bni_va" => 'bni_va',
            "danamon_online" => 'danamon_online',
            "other_va" => 'other_va',
            "kioson" => 'kioson',
            "Indomaret" => 'Indomaret',
        ];
    }
}

if (!function_exists("freekassa_payment_setting")) {
    function freekassa_payment_setting()
    {
        return [
            '1' => 'FK WALLET RUB',
            '2' => 'FK WALLET USD',
            '3' => 'FK WALLET EUR',
            '4' => 'VISA RUB',
            '6' => 'Yoomoney',
            '7' => 'VISA UAH',
            '8' => 'MasterCard RUB',
            '9' => 'MasterCard UAH',
            '10' => 'Qiwi',
            '11' => 'VISA EUR',
            '12' => 'МИР',
        ];
    }
}

/**
 * Local currency codes
 */
if (!function_exists("local_currency_code")) {
    function local_currency_code()
    {
        return [
            'USD','EUR','JPY','GBP','AUD','CAD','CHF','CNY','SEK','NZD','MXN','SGD','HKD','NOK',
            'KRW','TRY','RUB','INR','BRL','ZAR','AED','AFN','ALL','AMD','ANG','AOA','ARS','AWG','AZN',
            'BAM','BBD','BDT','BGN','BHD','BIF','BMD','BND','BOB','BSD','BTN','BWP','BYN','BZD','CDF',
            'CLF','CLP','COP','CRC','CUC','CUP','CVE','CZK','DJF','DKK','DOP','DZD','EGP','ERN','ETB',
            'FJD','FKP','GEL','GGP','GHS','GIP','GMD','GNF','GTQ','GYD','HNL','HRK','HTG','HUF','IDR',
            'ILS','IMP','IQD','IRR','ISK','JEP','JMD','JOD','KES','KGS','KHR','KMF','KPW','KWD','KYD',
            'KZT','LAK','LBP','LKR','LRD','LSL','LYD','MAD','MDL','MGA','MKD','MMK','MNT','MOP','MRO',
            'MUR','MVR','MWK','MYR','MZN','NAD','NGN','NIO','NPR','OMR','PAB','PEN','PGK','PHP','PKR',
            'PLN','PYG','QAR','RON','RSD','RWF','SAR','SBD','SCR','SDG','SHP','SLL','SOS','SRD','SSP',
            'STD','SVC','SYP','SZL','THB','TJS','TMT','TND','TOP','TTD','TWD','TZS','UAH','UGX','UYU',
            'UZS','VEF','VND','VUV','WST','XAF','XAG','XAU','XCD','XDR','XOF','XPD','XPF','XPT','YER',
            'ZMW','ZWL',
        ];
    }
}
